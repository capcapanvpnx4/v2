// handler.js - OPTIMIZED v4.0 — new menu, admin role, reseller menu, anti-spam
'use strict';

const fs   = require('fs');
const path = require('path');
const db   = require('./data/db');

/* ══════════════════════════════════════════
   PRICES CACHE
══════════════════════════════════════════ */
let _pricesCache = null;
const PRICES_PATH = path.join(__dirname, 'data', 'prices.js');

function loadPrices() {
  try {
    const resolved = require.resolve(PRICES_PATH);
    delete require.cache[resolved];
    _pricesCache = require(PRICES_PATH);
  } catch (e) {
    console.error('[handler] ❌ Gagal load prices.js:', e.message);
    _pricesCache = { reseller: {}, members: {} };
  }
}

loadPrices();
fs.watchFile(PRICES_PATH, { interval: 5000 }, () => { loadPrices(); });

function getPrices() {
  if (!_pricesCache) loadPrices();
  return _pricesCache;
}

function fRp(n) { return n ? Number(n).toLocaleString('id-ID') : '?'; }

/* ══════════════════════════════════════════
   OWNER / ADMIN CONFIG
══════════════════════════════════════════ */
let _avars = {};
try { _avars = JSON.parse(fs.readFileSync(path.join(__dirname, 'data/.avars.json'), 'utf8')); } catch (_) {}
const OWNER_ID = String(_avars.owner_id || '');

function getDisplayRole(chatId, dbRole) {
  if (String(chatId) === OWNER_ID) return 'admin';
  return dbRole || 'members';
}

/* ══════════════════════════════════════════
   LAZY REQUIRES
══════════════════════════════════════════ */
let _paymentChecker, _qris, _create, _renew, _triall;
let _menuDepositCmd, _trxCmd, _myaccountCmd, _voucherSvc;

function getListServer() {
  /* Always bust cache so server.used reflects latest writes */
  try {
    const p = require.resolve('./data/server');
    delete require.cache[p];
    return require('./data/server');
  } catch (e) { return []; }
}

function getPaymentChecker() {
  if (!_paymentChecker) _paymentChecker = require('./services/paymentChecker');
  return _paymentChecker;
}
function getQRIS()   { if (!_qris)   _qris   = require('./services/qris');      return _qris; }
function getCreate() { if (!_create) _create = require('./cmd/create');          return _create; }
function getRenew()  { if (!_renew)  _renew  = require('./cmd/renew');           return _renew; }
function getTriall() { if (!_triall) _triall = require('./cmd/triall');          return _triall; }
function getMenuDeposit() {
  if (!_menuDepositCmd) _menuDepositCmd = require('./cmd/menu_deposit'); return _menuDepositCmd;
}
function getTrxCmd() {
  if (!_trxCmd) _trxCmd = require('./cmd/trx'); return _trxCmd;
}
function getMyaccount() {
  if (!_myaccountCmd) _myaccountCmd = require('./cmd/myaccount'); return _myaccountCmd;
}
function getVoucherSvc() {
  if (!_voucherSvc) _voucherSvc = require('./services/voucher'); return _voucherSvc;
}

/* ══════════════════════════════════════════
   STATE MAPS — auto-cleanup
══════════════════════════════════════════ */
const userMenus     = new Map();
const userStates    = new Map();
const userTimestamp = new Map();

const processingUsers = new Set();
const userLastMsg     = new Map();
const lastCbTime      = new Map();
const lastCbData      = new Map();

const SESSION_TTL   = 30 * 60 * 1000;
const RATE_LIMIT_MS = 1500;
const CB_DEDUP_MS   = 1000;

const ACTIVE_FLOWS = new Set([
  'create_flow', 'renew_flow', 'triall_flow',
  'deposit_custom', 'tambah_saldo_reseller', 'renew_pick',
  'create_confirm', 'renew_confirm', 'claim_voucher'
]);

function touchSession(chatId) {
  userTimestamp.set(chatId, Date.now());
}

function cleanupSessions() {
  const now = Date.now();
  for (const [chatId, ts] of userTimestamp.entries()) {
    if (now - ts > SESSION_TTL) {
      userMenus.delete(chatId);
      userStates.delete(chatId);
      userTimestamp.delete(chatId);
      processingUsers.delete(chatId);
      userLastMsg.delete(chatId);
      lastCbTime.delete(chatId);
      lastCbData.delete(chatId);
    }
  }
}

setInterval(cleanupSessions, 15 * 60 * 1000);

/* ══════════════════════════════════════════
   HELPERS
══════════════════════════════════════════ */
function sendTempMsg(bot, chatId, text, ms = 2500) {
  bot.sendMessage(chatId, text, { parse_mode: 'HTML' })
    .then(m => setTimeout(() => bot.deleteMessage(chatId, m.message_id).catch(() => {}), ms))
    .catch(() => {});
}

async function editMsg(bot, chatId, msgId, text, opts = {}) {
  try {
    await bot.editMessageText(text, { chat_id: chatId, message_id: msgId, ...opts });
    return true;
  } catch (e) {
    if (e.message?.includes('message is not modified')) return true;
    return false;
  }
}

/* ══════════════════════════════════════════
   STATISTIK
══════════════════════════════════════════ */
function getAllStats(chatId) {
  return new Promise(resolve => {
    db.get(`
      SELECT
        COUNT(CASE WHEN status='completed' AND date(created_at)=date('now','localtime') THEN 1 END)                                       AS global_today,
        COUNT(CASE WHEN status='completed' AND strftime('%Y-%W',created_at)=strftime('%Y-%W','now','localtime') THEN 1 END)               AS global_week,
        COUNT(CASE WHEN status='completed' AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime') THEN 1 END)               AS global_month,
        COUNT(CASE WHEN status='completed' AND chat_id=? AND date(created_at)=date('now','localtime') THEN 1 END)                        AS user_today,
        COUNT(CASE WHEN status='completed' AND chat_id=? AND strftime('%Y-%W',created_at)=strftime('%Y-%W','now','localtime') THEN 1 END) AS user_week,
        COUNT(CASE WHEN status='completed' AND chat_id=? AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime') THEN 1 END) AS user_month,
        COALESCE(SUM(CASE WHEN status='completed' AND (order_id GLOB '[0-9]*') AND date(created_at)=date('now','localtime') THEN amount END), 0)                                 AS inc_today,
        COALESCE(SUM(CASE WHEN status='completed' AND (order_id GLOB '[0-9]*') AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime') THEN amount END), 0)        AS inc_month,
        COALESCE(SUM(CASE WHEN status='completed' AND (order_id GLOB '[0-9]*') THEN amount END), 0)                                                                              AS inc_total
      FROM transactions
    `, [chatId, chatId, chatId], (err, row) => {
      if (err || !row) return resolve({ g: { today:0, week:0, month:0 }, u: { today:0, week:0, month:0 }, inc: { today:0, month:0, total:0 } });
      resolve({
        g:   { today: row.global_today, week: row.global_week,  month: row.global_month },
        u:   { today: row.user_today,   week: row.user_week,    month: row.user_month   },
        inc: { today: row.inc_today,    month: row.inc_month,   total: row.inc_total    }
      });
    });
  });
}

/* ══════════════════════════════════════════
   BUILD MENU
══════════════════════════════════════════ */
async function buildMenuData(chatId) {
  const [row, stats] = await Promise.all([
    new Promise(r => db.get('SELECT saldo, role FROM users WHERE chat_id=?', [chatId], (e, v) => r(v || { saldo: 0, role: 'members' }))),
    getAllStats(chatId)
  ]);

  const saldo       = Number(row.saldo) || 0;
  const displayRole = getDisplayRole(chatId, row.role);
  const pr          = getPrices();
  const m           = pr.members  || {};
  const r2          = pr.reseller || {};

  const incomeSection = displayRole === 'admin'
    ? `├─────────────────┤
│ 💵 𝗜𝗡𝗖𝗢𝗠𝗘 𝗔𝗗𝗠𝗜𝗡 <i>(via QRIS)</i>
│ ├ Hari ini   : <b>Rp ${Number(stats.inc.today).toLocaleString('id-ID')}</b>
│ ├ Bulan ini  : <b>Rp ${Number(stats.inc.month).toLocaleString('id-ID')}</b>
│ └ Total      : <b>Rp ${Number(stats.inc.total).toLocaleString('id-ID')}</b>
`
    : '';

  const text = `┌─────────────────┐
│                       🔰 CAPCAPAN 🔰
└─────────────────┘
┌─────────────────┐
│ 👤 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡𝗦
│ ROLE    : <code>${displayRole.toUpperCase()}</code>
│ ID      : <code>${chatId}</code>
│ Balance : <code>Rp ${saldo.toLocaleString('id-ID')}</code>
└─────────────────┘
┌─────────────────┐
│ 💰 𝗣𝗥𝗜𝗖𝗘 𝗟𝗜𝗦𝗧 <i>(per hari)</i>
│ 𝙼𝙴𝙼𝙱𝙴𝚁𝚂
│ ├ SSH&X-Ray  : <b>Rp ${fRp(m.vmess?.perDay)}</b>
│ └ UDP ZivPN : <b>Rp ${fRp(m.udpzivpn?.perDay)}</b>
│ 𝚁𝙴𝚂𝙴𝙻𝙻𝙴𝚁
│ ├ SSH&X-Ray  : <b>Rp ${fRp(r2.vmess?.perDay)}</b>
│ └ UDP ZivPN : <b>Rp ${fRp(r2.udpzivpn?.perDay)}</b>
├─────────────────┤
│ 📊 𝗚𝗟𝗢𝗕𝗔𝗟 𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗞
│ ├ Hari ini   : <b>${stats.g.today}</b>
│ ├ Minggu ini : <b>${stats.g.week}</b>
│ └ Bulan ini  : <b>${stats.g.month}</b>
│ 📈 𝗬𝗢𝗨𝗥𝗦 𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗞
│ ├ Hari ini   : <b>${stats.u.today}</b>
│ ├ Minggu ini : <b>${stats.u.week}</b>
│ └ Bulan ini  : <b>${stats.u.month}</b>
${incomeSection}└─────────────────┘
`;

  const keyboard = [
    [
      { text: '📝 ORDERS ACCOUNT', callback_data: 'create_menu' },
      { text: '♻️ CREATE TRIALL',  callback_data: 'triall_menu' }
    ],
    [{ text: '👤 MY ACCOUNT',  callback_data: 'menu_myaccount' }],
    [{ text: '💎 RESELLER MENU', callback_data: 'reseller_menu' }],
    [{ text: '🎁 Claim Saldo Gratis', callback_data: 'menu_claim_voucher' }]
  ];

  return { text, keyboard, parse_mode: 'HTML' };
}

/* ══════════════════════════════════════════
   RESELLER MENU
══════════════════════════════════════════ */
function editResellerMenu(bot, chatId, msgId) {
  const text =
    `┌─────────────────┐\n│  💎 RESELLER MENU\n└─────────────────┘\n\n` +
    `<b>Apa itu Reseller?</b>\n` +
    `Reseller mendapat harga lebih murah dan bisa menjual kembali layanan VPN kepada pelanggan.\n\n` +
    `<b>Cara menjadi Reseller:</b>\n` +
    `├ Top up saldo minimal <b>Rp 20.000</b>\n` +
    `└ Status reseller otomatis aktif\n\n` +
    `<b>Cara menjadi Admin:</b>\n` +
    `└ Hubungi owner langsung\n\n` +
    `<b>Keuntungan Reseller:</b>\n` +
    `├ Harga lebih murah dari members\n` +
    `├ Limit IP gratis s/d 5 IP/akun\n` +
    `└ Akses semua protokol VPN`;

  return editMsg(bot, chatId, msgId, text, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [{ text: '💰 Top Up Reseller',     callback_data: 'menu_deposit'           }],
        [{ text: '➕ Tambah Saldo Reseller', callback_data: 'menu_tambah_saldo'      }],
        [{ text: '🔃 Kembali ke Menu',      callback_data: 'menu_back'             }]
      ]
    }
  });
}

/* ══════════════════════════════════════════
   SEND / EDIT MENU
══════════════════════════════════════════ */
async function sendMainMenu(bot, chatId) {
  touchSession(chatId);

  if (userMenus.has(chatId)) {
    bot.deleteMessage(chatId, userMenus.get(chatId)).catch(() => {});
    userMenus.delete(chatId);
  }

  const loadingMsg = await bot.sendMessage(chatId, '⏳ <i>Memuat menu...</i>', { parse_mode: 'HTML' }).catch(() => null);
  if (!loadingMsg) return;

  const msgId = loadingMsg.message_id;
  userMenus.set(chatId, msgId);

  try {
    const { text, keyboard, parse_mode } = await buildMenuData(chatId);
    await editMsg(bot, chatId, msgId, text, { parse_mode, reply_markup: { inline_keyboard: keyboard } });
  } catch (err) {
    console.error('[sendMainMenu] ❌', err.message);
    bot.editMessageText('❌ Gagal load menu. Ketik /menu untuk coba lagi.', {
      chat_id: chatId, message_id: msgId
    }).catch(() => {});
  }
}

async function editMainMenu(bot, chatId, msgId) {
  touchSession(chatId);
  const ok0 = await editMsg(bot, chatId, msgId, '⏳ <i>Memuat menu...</i>', { parse_mode: 'HTML' });
  if (!ok0) return false;
  try {
    const { text, keyboard, parse_mode } = await buildMenuData(chatId);
    const ok = await editMsg(bot, chatId, msgId, text, { parse_mode, reply_markup: { inline_keyboard: keyboard } });
    if (ok) userMenus.set(chatId, msgId);
    return ok;
  } catch (err) {
    console.error('[editMainMenu] ❌', err.message);
    return false;
  }
}

/* ══════════════════════════════════════════
   SERVER / PROTOCOL MENUS
══════════════════════════════════════════ */
function editServerSelection(bot, chatId, msgId, actionType) {
  const LIST_SERVER = getListServer();
  const keyboard = LIST_SERVER.map((srv, idx) => {
    const used   = srv.used  || 0;
    const limit  = srv.limit || 0;
    const status = (limit > 0 && used >= limit) ? '🔴 FULL' : `🟢 ${used}/${limit}`;
    return [{ text: `${srv.name} — ${status}`, callback_data: `select_${actionType}_${idx}` }];
  });
  keyboard.push([{ text: '🔃 BACK TO MENU', callback_data: 'menu_back' }]);
  return editMsg(bot, chatId, msgId,
    `┌─────────────────┐\n│  🖥 SELECT VPS SERVER\n└─────────────────┘\n\nPilih server untuk layanan VPN:`,
    { reply_markup: { inline_keyboard: keyboard } }
  );
}

function editCreateMenu(bot, chatId, msgId) {
  const keyboard = [
    [
      { text: '⚪ SSH / OpenVPN', callback_data: 'ssh_create' },
      { text: '🔵 xRay VMess',   callback_data: 'vme_create' }
    ],
    [{ text: '🟢 UDP ZivPN', callback_data: 'ziv_create' }],
    [
      { text: '🟡 xRay VLess',   callback_data: 'vle_create' },
      { text: '🟠 xRay Trojan',  callback_data: 'tro_create' }
    ],
    [{ text: '🔃 BACK TO MENU', callback_data: 'menu_back' }]
  ];
  return editMsg(bot, chatId, msgId,
    `┌─────────────────┐\n│  🔰 CREATE VPN PREMIUM\n└─────────────────┘\n\nPilih protokol:`,
    { reply_markup: { inline_keyboard: keyboard } }
  );
}

function editTriallMenu(bot, chatId, msgId) {
  const keyboard = [
    [
      { text: '⚪ SSH / OpenVPN', callback_data: 'ssh_triall' },
      { text: '🔵 xRay VMess',   callback_data: 'vme_triall' }
    ],
    [{ text: '🟢 UDP ZivPN', callback_data: 'ziv_triall' }],
    [
      { text: '🟡 xRay VLess',   callback_data: 'vle_triall' },
      { text: '🟠 xRay Trojan',  callback_data: 'tro_triall' }
    ],
    [{ text: '🔃 BACK TO MENU', callback_data: 'menu_back' }]
  ];
  return editMsg(bot, chatId, msgId,
    `┌─────────────────┐\n│  ♻️ CREATE VPN TRIAL\n└─────────────────┘\n\n⏱ Durasi: 30 menit  🆓 Gratis!\nPilih protokol:`,
    { reply_markup: { inline_keyboard: keyboard } }
  );
}

/* ══════════════════════════════════════════
   WELCOME
══════════════════════════════════════════ */
function sendWelcome(bot, chatId) {
  bot.sendMessage(chatId,
`┌─────────────────┐
│       🔺 CAPCAPAN AUTOBOT VPN 🔻
└─────────────────┘
Selamat datang di AutoBot VPN! 👋

Kami menyediakan layanan VPN premium:
⚪ SSH / OpenVPN
🔵 xRay VMess
🟡 xRay VLess
🟠 xRay Trojan
🟢 UDP ZivPN

Klik tombol di bawah untuk mulai!`,
    { reply_markup: { inline_keyboard: [[{ text: '🛒 Ke Menu Utama', callback_data: 'menu_back' }]] } }
  ).catch(err => console.error('[sendWelcome]', err.message));
}

/* ══════════════════════════════════════════
   MAIN HANDLER
══════════════════════════════════════════ */
function handler(bot) {

  /* ── PESAN TEKS ── */
  bot.on('message', async (msg) => {
    try {
      const chatId = msg.chat.id;
      const text   = msg.text?.trim();
      if (!text) return;

      bot.deleteMessage(chatId, msg.message_id).catch(() => {});
      touchSession(chatId);

      const stateObj = userStates.get(chatId);
      const state    = stateObj?.state;

      /* RATE LIMITER */
      if (state && ACTIVE_FLOWS.has(state)) {
        const last = userLastMsg.get(chatId);
        const now  = Date.now();
        if (last && (now - last) < RATE_LIMIT_MS) {
          sendTempMsg(bot, chatId, '⏳ <b>Terlalu cepat!</b> Tunggu sebentar ya.', 2000);
          return;
        }
        userLastMsg.set(chatId, now);
      }

      /* PROCESSING LOCK */
      if (processingUsers.has(chatId)) {
        sendTempMsg(bot, chatId, '⌛ <b>Sedang diproses...</b> Tunggu sebentar.', 2000);
        return;
      }

      processingUsers.add(chatId);
      try {
        if (state === 'create_flow') { await getCreate().handleStep(bot, chatId, text, userStates); return; }
        if (state === 'renew_flow')  { await getRenew().handleStep(bot, chatId, text, userStates);  return; }
        if (state === 'triall_flow') { await getTriall().handleStep(bot, chatId, text, userStates); return; }

        if (state === 'deposit_custom') {
          if (!/^\d+$/.test(text)) { sendTempMsg(bot, chatId, '❌ Masukkan angka saja. Contoh: <code>20000</code>', 3000); return; }
          const amount = parseInt(text);
          if (amount < 20000) { sendTempMsg(bot, chatId, '❌ Minimal Top Up <b>Rp 20.000</b>', 3000); return; }
          userStates.delete(chatId);
          getQRIS().generateQRIS(bot, chatId, amount);
          return;
        }

        if (state === 'tambah_saldo_reseller') {
          if (!/^\d+$/.test(text)) { sendTempMsg(bot, chatId, '❌ Masukkan angka saja. Contoh: <code>10000</code>', 3000); return; }
          const amount = parseInt(text);
          if (amount < 10000) { sendTempMsg(bot, chatId, '❌ Minimal top up <b>Rp 10.000</b>', 3000); return; }
          db.get('SELECT role FROM users WHERE chat_id=?', [chatId], (err, row) => {
            if (!row || (row.role !== 'reseller' && row.role !== 'admin')) {
              userStates.delete(chatId);
              sendTempMsg(bot, chatId, '❌ Wajib <b>Reseller</b> terlebih dahulu. Top Up dulu minimal Rp 20.000.', 4000);
              return;
            }
            userStates.delete(chatId);
            getQRIS().generateQRIS(bot, chatId, amount);
          });
          return;
        }

        if (state === 'renew_pick') {
          const num = parseInt(text);
          const { accounts, listMsgId } = stateObj;
          if (isNaN(num) || num < 1 || num > accounts.length) {
            sendTempMsg(bot, chatId, `❌ Pilih angka <b>1</b> sampai <b>${accounts.length}</b>`, 3000);
            return;
          }
          getRenew().initRenew(bot, chatId, userStates, accounts[num - 1], listMsgId);
          return;
        }

        if (state === 'claim_voucher') {
          userStates.delete(chatId);
          const claimMsgId = stateObj.msgId;
          const code = text.trim();

          const result = await getVoucherSvc().claimVoucher(code, chatId);

          const reasonMsg = {
            not_found:      '❌ Kode voucher tidak ditemukan.',
            inactive:       '❌ Voucher sudah tidak aktif.',
            exhausted:      '❌ Voucher sudah habis diklaim.',
            already_claimed:'❌ Kamu sudah pernah mengklaim voucher ini.'
          };

          if (!result.ok) {
            const errText = reasonMsg[result.reason] || '❌ Klaim gagal.';
            if (claimMsgId) {
              return editMsg(bot, chatId, claimMsgId, errText, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
              });
            }
            return sendTempMsg(bot, chatId, errText, 4000);
          }

          /* ── Berhasil claim → notif ke admin ── */
          const fromInfo = msg.from;
          const username  = fromInfo?.username  ? `@${fromInfo.username}` : '(no username)';
          const firstName = fromInfo?.first_name || '';
          const notifText =
            `🎁 <b>Voucher Berhasil Diklaim!</b>\n\n` +
            `👤 User     : ${firstName} ${username}\n` +
            `🆔 Telegram ID: <code>${chatId}</code>\n` +
            `🎟 Kode     : <code>${code}</code>\n` +
            `💰 Saldo    : <b>Rp ${Number(result.saldo).toLocaleString('id-ID')}</b>`;
          bot.sendMessage(OWNER_ID, notifText, { parse_mode: 'HTML' }).catch(() => {});

          const successText =
            `✅ <b>Voucher Berhasil Diklaim!</b>\n\n` +
            `┌─────────────────────┐\n` +
            `│ 🎟 Kode  : <code>${code}</code>\n` +
            `│ 💰 Saldo : <b>+Rp ${Number(result.saldo).toLocaleString('id-ID')}</b>\n` +
            `│ 💳 Total : <b>Rp ${Number(result.newSaldo).toLocaleString('id-ID')}</b>\n` +
            `└─────────────────────┘`;

          if (claimMsgId) {
            return editMsg(bot, chatId, claimMsgId, successText, {
              parse_mode: 'HTML',
              reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
            });
          }
          return sendTempMsg(bot, chatId, successText, 5000);
        }

        if (text === '/start') {
          db.get('SELECT chat_id FROM users WHERE chat_id=?', [chatId], (err, row) => {
            if (!row) {
              db.run(
                "INSERT INTO users (chat_id, saldo, role, created_at) VALUES (?, 0, 'members', datetime('now','localtime'))",
                [chatId]
              );
            }
            sendWelcome(bot, chatId);
          });
        } else if (text === '/menu') {
          sendMainMenu(bot, chatId).catch(err => console.error('[/menu]', err.message));
        } else if (text === '/cancel') {
          userStates.delete(chatId);
          userLastMsg.delete(chatId);
          sendTempMsg(bot, chatId, '❌ Proses dibatalkan. Ketik /menu untuk kembali.', 4000);
        } else if (text === '/contact' || text?.startsWith('/contact')) {
          bot.sendMessage(chatId,
`📞 <b>HUBUNGI ADMIN</b>

👤 <b>SeorangYan</b>

📱 WhatsApp:
<a href="https://wa.me/6283197765857">wa.me/6283197765857</a>

💬 Telegram: @yanbhoikfost

<i>Admin siap membantu 24 jam!</i>`,
            { parse_mode: 'HTML', disable_web_page_preview: true }
          ).catch(() => {});
        }
      } finally {
        processingUsers.delete(chatId);
      }

    } catch (err) {
      console.error('[message handler] ❌', err.message);
      processingUsers.delete(msg?.chat?.id);
    }
  });

  /* ── CALLBACK QUERY ── */
  bot.on('callback_query', async (query) => {
    try {
      const chatId = query.message.chat.id;
      const msgId  = query.message.message_id;
      const data   = query.data;

      if (data.startsWith('adm_')) return;

      /* CALLBACK DEDUP */
      const now      = Date.now();
      const prevTime = lastCbTime.get(chatId);
      const prevData = lastCbData.get(chatId);
      if (prevData === data && prevTime && (now - prevTime) < CB_DEDUP_MS) {
        bot.answerCallbackQuery(query.id, { text: '⏳ Tunggu sebentar...', show_alert: false }).catch(() => {});
        return;
      }
      lastCbTime.set(chatId, now);
      lastCbData.set(chatId, data);

      bot.answerCallbackQuery(query.id).catch(() => {});
      touchSession(chatId);

      /* ── NAVIGASI ── */
      if (data === 'menu_back') {
        userStates.delete(chatId);
        userLastMsg.delete(chatId);
        const ok = await editMainMenu(bot, chatId, msgId);
        if (!ok) await sendMainMenu(bot, chatId);
        return;
      }

      if (data === 'create_menu') return editServerSelection(bot, chatId, msgId, 'create');
      if (data === 'triall_menu') return editServerSelection(bot, chatId, msgId, 'triall');
      if (data === 'renew_menu')  return getRenew().showAccountList(bot, chatId, msgId, userStates);
      if (data === 'reseller_menu') return editResellerMenu(bot, chatId, msgId);

      if (data.startsWith('select_')) {
        const parts = data.split('_'), type = parts[1], idx = parseInt(parts[2]);
        const LIST_SERVER = getListServer();
        const stateData = userStates.get(chatId) || {};
        userStates.set(chatId, { ...stateData, state: null, serverIp: LIST_SERVER[idx]?.ip });
        if (type === 'create') return editCreateMenu(bot, chatId, msgId);
        if (type === 'triall') return editTriallMenu(bot, chatId, msgId);
        return;
      }

      if (data.startsWith('ssh_') || data.startsWith('vme_') || data.startsWith('vle_') ||
          data.startsWith('tro_') || data.startsWith('ziv_')) {
        const [proto, action] = data.split('_');
        const typeMap = { ssh: 'ssh', vme: 'vmess', vle: 'vless', tro: 'trojan', ziv: 'zivpn' };
        const type = typeMap[proto];
        if (!type) return;

        if (action === 'create') {
          const createMod = getCreate();
          const fnMap = {
            ssh: createMod.createSSH, vmess: createMod.createVMess,
            vless: createMod.createVLess, trojan: createMod.createTrojan, zivpn: createMod.createZivpn
          };
          return fnMap[type]?.(bot, chatId, userStates, msgId);
        }
        if (action === 'triall') {
          const triallMod = getTriall();
          const fnMap = {
            ssh: triallMod.triallSSH, vmess: triallMod.triallVMess,
            vless: triallMod.triallVLess, trojan: triallMod.triallTrojan, zivpn: triallMod.triallZivpn
          };
          return fnMap[type]?.(bot, chatId, userStates, msgId);
        }
      }

      if (data === 'confirm_order') {
        const st = userStates.get(chatId);
        if (!st || st.state !== 'create_confirm') return;
        return getCreate().executeCreate(bot, chatId, userStates, st);
      }

      if (data === 'cancel_order') {
        userStates.delete(chatId);
        userLastMsg.delete(chatId);
        return editMsg(bot, chatId, msgId, '❌ Order dibatalkan.', {
          reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
        });
      }

      if (data === 'confirm_renew') {
        const st = userStates.get(chatId);
        if (!st || st.state !== 'renew_confirm') return;
        return getRenew().executeRenew(bot, chatId, userStates, st);
      }

      if (data === 'cancel_renew') {
        userStates.delete(chatId);
        userLastMsg.delete(chatId);
        return editMsg(bot, chatId, msgId, '❌ Extend dibatalkan.', {
          reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
        });
      }

      if (data === 'menu_claim_voucher') {
        userStates.set(chatId, { state: 'claim_voucher', msgId });
        return editMsg(bot, chatId, msgId,
          `┌─────────────────────┐\n` +
          `│  🎁 CLAIM SALDO GRATIS\n` +
          `└─────────────────────┘\n\n` +
          `Kamu bisa mendapatkan saldo gratis dengan kode <b>Voucher</b> yang dibagikan oleh admin.\n\n` +
          `📌 <b>Format kode:</b> <code>yan_XXXXXXX</code>\n\n` +
          `✍️ Ketik kode voucher kamu di bawah:`,
          {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_back' }]] }
          }
        );
      }

      if (data === 'menu_history')   return getTrxCmd()(bot, chatId, msgId);
      if (data === 'menu_myaccount') return getMyaccount()(bot, chatId, msgId, 0);
      if (data.startsWith('myacc_p_')) {
        const page = parseInt(data.replace('myacc_p_', '')) || 0;
        return getMyaccount()(bot, chatId, msgId, page);
      }
      if (data === 'menu_deposit')   return getMenuDeposit()(bot, chatId, msgId);

      if (data === 'menu_tambah_saldo') {
        return db.get('SELECT role FROM users WHERE chat_id=?', [chatId], async (err, row) => {
          if (!row || (row.role !== 'reseller' && row.role !== 'admin')) {
            return editMsg(bot, chatId, msgId,
              `❌ <b>Fitur ini khusus untuk Reseller.</b>\n\nTop Up minimal <b>Rp 20.000</b> untuk mendapatkan status Reseller secara otomatis.\n\nKlik tombol di bawah untuk top up:`,
              { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                [{ text: '💰 Top Up Sekarang', callback_data: 'menu_deposit' }],
                [{ text: '🔃 Kembali',         callback_data: 'reseller_menu' }]
              ]}}
            );
          }
          userStates.set(chatId, { state: 'tambah_saldo_reseller' });
          return editMsg(bot, chatId, msgId,
            `💰 <b>TAMBAH SALDO RESELLER</b>\n\nMasukkan jumlah top up (minimal Rp 10.000):\n<i>contoh: 50000</i>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_back' }]] } }
          );
        });
      }

      if (data.startsWith('deposit_')) {
        const amount = parseInt(data.replace('deposit_', ''));
        if (!isNaN(amount) && amount >= 10000) {
          return getQRIS().generateQRIS(bot, chatId, amount);
        }
        if (data === 'deposit_custom') {
          userStates.set(chatId, { state: 'deposit_custom' });
          return editMsg(bot, chatId, msgId,
            `✏️ <b>TOP UP KUSTOM</b>\n\nMasukkan jumlah top up (minimal Rp 20.000):\n<i>contoh: 35000</i>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_back' }]] } }
          );
        }
      }

      if (data.startsWith('refresh_')) {
        const orderId = data.replace('refresh_', '');
        return getPaymentChecker().handleRefresh(bot, chatId, orderId);
      }

      /* ── BATAL QRIS ── */
      if (data.startsWith('cancel_qris_')) {
        const orderId = data.replace('cancel_qris_', '');
        try { const { clearQrisCountdown } = getQRIS(); clearQrisCountdown(orderId); } catch (_) {}
        getPaymentChecker().removePendingOrder(orderId);
        db.run("UPDATE transactions SET status='canceled' WHERE order_id=?", [orderId]);
        /* QRIS dikirim sebagai photo → pakai editMessageCaption bukan editMessageText */
        return bot.editMessageCaption(
          `❌ <b>QRIS Dibatalkan</b>\n\n` +
          `Order ID: <code>${orderId}</code>\n\n` +
          `Pembayaran dibatalkan oleh pengguna.\n` +
          `Buat order baru melalui menu di bawah.`,
          {
            chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
          }
        ).catch(() => {
          /* Fallback: kirim pesan baru jika edit gagal */
          bot.sendMessage(chatId,
            `❌ <b>QRIS Dibatalkan</b>\n\nOrder ID: <code>${orderId}</code>\n\nKetik /menu untuk buat order baru.`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] } }
          ).catch(() => {});
        });
      }

    } catch (err) {
      console.error('[callback_query] ❌', err.message);
    }
  });
}

module.exports = handler;
