const ERROR_MAP = {
  'CONFIG_NOT_FOUND':   'Konfigurasi Xray tidak ditemukan di server. Hubungi admin.',
  'CONFIG_CORRUPT':     'File konfigurasi Xray rusak (bukan JSON valid). Hubungi admin.',
  'XRAY_INVALID':       'Konfigurasi Xray tidak valid setelah perubahan. Hubungi admin.',
  'XRAY_BINARY_MISSING':'Binary Xray tidak ditemukan di server. Hubungi admin.',
  'XRAY_TAGS_MISSING':  'Inbound tags yang dibutuhkan tidak ditemukan di config Xray. Hubungi admin.',
  'JSON_BROKEN':        'Hasil modifikasi config bukan JSON valid. Hubungi admin.',
  'JQ_FAILED':          'Gagal memproses konfigurasi (jq error). Hubungi admin.',
  'USER_EXISTS':        'Username sudah digunakan. Silakan pilih username lain.',
  'USER_NOT_FOUND':     'Username tidak ditemukan di server.',
  'NO_USERNAME':        'Username tidak boleh kosong.',
  'INVALID_USERNAME':   'Username hanya boleh mengandung huruf, angka, dan underscore.',
  'INVALID_DAYS':       'Jumlah hari tidak valid.',
  'RENEW_XRAY_INVALID': 'Konfigurasi Xray tidak valid setelah perpanjangan. Perubahan dibatalkan. Hubungi admin.',
};

function friendlyError(rawOutput) {
  if (!rawOutput) return null;
  const match = rawOutput.match(/ERROR:(\S+)/);
  if (!match) return null;
  const code = match[1];
  return ERROR_MAP[code] || `Error tidak dikenal: ${code}. Hubungi admin.`;
}

function hasErrorCode(rawOutput) {
  return rawOutput && /ERROR:\S+/.test(rawOutput);
}

module.exports = { ERROR_MAP, friendlyError, hasErrorCode };
