// services/report.js
'use strict';

const db   = require('../data/db');
const fs   = require('fs');
const path = require('path');

let avars = {};
try {
  avars = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8'));
} catch (e) {
  console.warn('[report] .avars.json tidak ditemukan, laporan harian dinonaktifkan.');
}

const OWNER_ID = Number(avars.owner_id);

function sendDailyReport(bot) {
  if (!OWNER_ID) return;

  db.get(`
    SELECT COUNT(*) as total_tx, SUM(amount) as total_income
    FROM transactions
    WHERE status='completed' AND date(created_at) = date('now','localtime')
  `, [], async (err, row) => {
    const total  = row?.total_income || 0;
    const trx    = row?.total_tx    || 0;
    const tanggal = new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

    bot.sendMessage(OWNER_ID,
`📊 <b>LAPORAN HARIAN</b>

📅 ${tanggal}

💰 Total Income     : <b>Rp ${total.toLocaleString('id-ID')}</b>
📦 Total Transaksi  : <b>${trx}</b>

🔥 Keep grinding!`,
      { parse_mode: 'HTML' }
    ).catch(err => console.error('[report] Gagal kirim laporan:', err.message));
  });
}

function scheduleNextReport(bot) {
  const now  = new Date();
  const next = new Date();
  next.setHours(23, 59, 0, 0);
  if (next <= now) next.setDate(next.getDate() + 1);
  const delay = next - now;

  setTimeout(() => {
    sendDailyReport(bot);
    scheduleNextReport(bot);
  }, delay);
}

function startDailyReport(bot) {
  if (!OWNER_ID) return;
  scheduleNextReport(bot);
  console.log('[report] ✅ Daily report scheduler aktif');
}

module.exports = { startDailyReport };
